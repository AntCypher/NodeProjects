<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) )
    exit;

/**
 * Template Name: Custom Post Template
 *
 * @package WordPress
 * @subpackage seg
 * @since seg 1.0
 */
get_header();
?>
<?php

//die;
function json_decode_add_quotes_to_keys($s) {
    $s = preg_replace( '/(\w+):/i', '"\1":', $s );
    return json_decode( $s, true );
}

//$jsonobj = '[{description:"Our choice of SEG proved to be one of the best decisions we’ve made. Their combination of smarts, connections, and guidance was right on. And while other firms might claim to offer similar capabilities, only SEG adds their unique style and chemistry to everything they do.",
//name:"York Bau",
//designation:"CEO, MoxiWorks"},{description:"Our choice of SEG proved to be one of the best decisions we’ve made. Their combination of smarts, connections, and guidance was right on. And while other firms might claim to offer similar capabilities, only SEG adds their unique style and chemistry to everything they do.",
//name:"York Bau",
//designation:"CEO, MoxiWorks"}]';
//
//    $output  = json_decode_add_quotes_to_keys( $jsonobj );
//    echo "<pre>";
//    print_r($output);
//    echo "</pre>";
die;
if ( ($handle = fopen( "https://seg.compview.co/wp-content/uploads/2022/03/seg-transactions-Sheet1.csv", "r" )) !== FALSE ) {
    while ( ($data = fgetcsv( $handle, 10000, "," )) !== FALSE ) {
        if ( count( array_filter( $data ) ) != 0 ) {
            $final_data[] = $data;
        }
    }
    fclose( $handle );
}
$final_data = array_slice( $final_data, 2 );      // returns "c", "d", and "e"
//echo "<pre>";
//print_r( $final_data );
//echo "</pre>";
foreach ( $final_data as $key => $value ) {
    $post_title                = $value[ 0 ];
    $post_url                  = $value[ 1 ];
    $seo_title                 = $value[ 2 ];
    $seo_des                   = $value[ 3 ];
    $hide_in_tra_slider        = $value[ 4 ];
    $transaction_logo_imgs     = $value[ 5 ];
    $bread_crumb_post_title    = $value[ 6 ];
    $banner_title              = $value[ 7 ];
    $banner_description        = $value[ 8 ];
    $video_img                 = $value[ 9 ];
    $video_popup_iframe        = $value[ 10 ];
    $person_name               = $value[ 11 ];
    $person_designation        = $value[ 12 ];
    $testi_content             = $value[ 13 ];
    $images                    = $value[ 14 ];
    $img_bottom_text           = $value[ 15 ];
    $client_des_title          = $value[ 16 ];
    $client_description        = $value[ 17 ];
    $invest_des_title          = $value[ 18 ];
    $invest_description        = $value[ 19 ];
    $hide_tran_section         = $value[ 20 ];
    $slider_title              = $value[ 21 ];
    $press_subtitle            = $value[ 22 ];
    $press_title               = $value[ 23 ];
    $press_descr               = $value[ 24 ];
    $read_full_press_cta_label = $value[ 25 ];
    $read_full_press_cta_link  = $value[ 26 ];
    $product_categories        = $value[ 27 ];
    $vertical_categories       = $value[ 28 ];
    $primary_product           = $value[ 29 ];
    $primary_vertical          = $value[ 30 ];
    $secondery_product         = $value[ 31 ];
    $secondery_vertical        = $value[ 32 ];
    $my_post                   = array (
        'post_type'   => SEG_TRANSACTION_POST_TYPE,
        'post_title'  => $post_title,
        'post_name'   => $post_url,
        'post_status' => 'publish'
    );
//    $post_id                   = wp_insert_post( $my_post );
    $product_categories        = explode( ",", $product_categories );
    $vertical_categories       = explode( ",", $vertical_categories );

    if ( $post_id ) {
//        if ( class_exists( 'WPSEO_Primary_Term' ) ) {
//            $prim_term = get_term_by( 'name', $primary_product, 'product' );
//            update_post_meta( $post_id, WPSEO_Meta::$meta_prefix . 'primary_' . 'product', $prim_term );
//
////            $wpseo_primary_term = new WPSEO_Primary_Term( $term, $post_id );
////        $primary_term       = get_term( $wpseo_primary_term->get_primary_term() );
////            // Set primary term.
////            $primaryTermObject      = new WPSEO_Primary_Term( $prim_term, $post_id );
////            $primaryTermObject->set_primary_term( 'product' );
////            // Save primary term.
////            $primaryTermObjectAdmin = new WPSEO_Primary_Term_Admin();
////            $primaryTermObjectAdmin->save_primary_terms( $post_id );
//        }
        $terms = array ();
        foreach ( $product_categories as $key => $value ) {
            if ( ! term_exists( $value, 'product' ) ) {
                $term_id = wp_insert_term( $value, 'product' );
                $terms[] = $term_id[ 'term_id' ];
                wp_set_post_terms( $post_id, $terms, 'product' );
            } else {
                $term_name = get_term_by( 'name', $value, 'product' );
                $terms[]   = $term_name->term_id;
                wp_set_post_terms( $post_id, $terms, 'product' );
            }
        }
        $terms_vector = array ();
        foreach ( $vertical_categories as $key => $value ) {
            if ( ! term_exists( $value, 'vertical' ) ) {
                $term_id        = wp_insert_term( $value, 'vertical' );
                $terms_vector[] = $term_id[ 'term_id' ];
                wp_set_post_terms( $post_id, $terms_vector, 'vertical' );
            } else {
                $term_name      = get_term_by( 'name', $value, 'vertical' );
                $terms_vector[] = $term_name->term_id;
                wp_set_post_terms( $post_id, $terms_vector, 'vertical' );
            }
        }
        //for secondery terms
        $secondery_product_name  = get_term_by( 'name', $secondery_product, 'product' );
        $secondery_product_id    = $secondery_product_name->term_id;
        update_field( 'seg_product_secondery', $secondery_product_id, $post_id );
        $secondery_vertical_name = get_term_by( 'name', $secondery_vertical, 'vertical' );
        $secondery_vertical_id   = $secondery_vertical_name->term_id;
        update_field( 'seg_vertical_secondery', $secondery_vertical_id, $post_id );

//        if ( $hide_in_tra_slider == 'true' ) {
//            update_field( 'seg_hide_in_transaction_slider', 1, $post_id );
//        } elseif ( $hide_in_tra_slider == 'false' ) {
//            update_field( 'seg_hide_in_transaction_slider', 0, $post_id );
//        }
//        
//        
        if ( ! empty( $bread_crumb_post_title ) ) {
            update_field( 'seg_trans_bread_title', $bread_crumb_post_title, $post_id );
        }
        if ( ! empty( $banner_title ) ) {
            update_field( 'seg_trans_banner_title', $banner_title, $post_id );
        }
        if ( ! empty( $banner_description ) ) {
            update_field( 'seg_trans_banner_content', $banner_description, $post_id );
        }
//        if ( ! empty( $video_img ) ) {
//            update_field( 'seg_trans_video_img', $video_img, $post_id );
//        }
        if ( ! empty( $video_popup_iframe ) ) {
            update_field( 'seg_trans_video_iframe', $video_popup_iframe, $post_id );
        }
        if ( ! empty( $person_name ) ) {
            update_field( 'seg_trans_video_subtext', $person_name, $post_id );
        }
        if ( ! empty( $person_designation ) ) {
            update_field( 'seg_trans_video_designation', $person_designation, $post_id );
        }
        if ( ! empty( $testi_content ) ) {
            $additions = json_decode_add_quotes_to_keys( '[' . $testi_content . ']' );
        }
        $existing = get_field( 'seg_trans_test_content' );
        if ( ! is_array( $existing ) ) {
            $existing = [];
        }
        $updated = $existing + $additions;
        update_field( 'seg_trans_test_content', $updated, $post_id );

//        if ( ! empty( $images ) ) {
//            update_field( 'seg_trans_desr_logos', $images, $post_id );
//        }
        if ( ! empty( $img_bottom_text ) ) {
            update_field( 'seg_trans_des_img_subtext', $img_bottom_text, $post_id );
        }
        if ( ! empty( $client_des_title ) ) {
            update_field( 'seg_trans_right_title', $client_des_title, $post_id );
        }
//
        if ( ! empty( $client_description ) ) {
            $additions_client = json_decode_add_quotes_to_keys( '[' . $client_description . ']' );
        }
        $existing_client_con = get_field( 'seg_trans_right_content' );
        if ( ! is_array( $existing_client_con ) ) {
            $existing_client_con = [];
        }
        $updated_client_con = $existing_client_con + $additions_client;
        update_field( 'seg_trans_right_content', $updated_client_con, $post_id );
//
//        if ( ! empty( $client_description ) ) {
//            update_field( 'seg_trans_right_content', $client_description, $post_id );
//        }
//
//
        if ( ! empty( $invest_des_title ) ) {
            update_field( 'seg_trans_left_title', $invest_des_title, $post_id );
        }
//left content
        if ( ! empty( $invest_description ) ) {
            $additions_invest = json_decode_add_quotes_to_keys( '[' . $invest_description . ']' );
        }
        $existing_invest_con = get_field( 'seg_trans_left_content' );
        if ( ! is_array( $existing_invest_con ) ) {
            $existing_invest_con = [];
        }
        $updated_invest_con = $existing_invest_con + $additions_invest;
        update_field( 'seg_trans_left_content', $updated_invest_con, $post_id );
//
//        if ( ! empty( $invest_description ) ) {
//            update_field( 'seg_trans_left_content', $invest_description, $post_id );
//        }
        if ( ! empty( $hide_tran_section ) ) {
            update_field( 'seg_trans_slider_hide', $hide_tran_section, $post_id );
        }
        if ( ! empty( $slider_title ) ) {
            update_field( 'seg_trans_slider_title', $slider_title, $post_id );
        }
        if ( ! empty( $press_subtitle ) ) {
            update_field( 'seg_press_subtitle', $press_subtitle, $post_id );
        }
        if ( ! empty( $press_title ) ) {
            update_field( 'seg_press_title', $press_title, $post_id );
        }
        if ( ! empty( $press_descr ) ) {
            update_field( 'seg_press_content', $press_descr, $post_id );
        }

        $press_arr = array (
            'title' => $read_full_press_cta_label,
            'url'   => $read_full_press_cta_link,
        );
        if ( ! empty( $press_arr ) ) {
            update_field( 'seg_press_read_cta', $press_arr, $post_id );
        }
    }
}
?>




<?php
//$video_subtitle = get_field( 'title' );
//
//echo "<pre>";
//print_r( $video_subtitle );
//echo "</pre>";
//$arrr = [];
//foreach ( $video_subtitle as $key => $value ) {
//    $arrr[] = $value[ 'subtitle' ];
//}
//
//$arrr = implode( ' / ', $arrr );
//echo "<pre>";
//print_r( $arrr );
//echo "</pre>";
//
//if ( ! empty( $video_subtitle ) ) {
//    $sub_arr = array_map( function ($item) {
//        return "<span>" . $item[ 'subtitle' ] . "</span>";
//    }, $video_subtitle );
//}
//echo "<pre>";
//print_r( $sub_arr );
//echo "</pre>";
//$sub_arr      = implode( ' / ', $sub_arr );
//echo "<pre>";
//print_r( $sub_arr );
//echo "</pre>";
//    --------------------------------------
/**
$page_id      = get_the_ID();
$page_title   = get_the_title();
$page_content = get_the_content();
$page_link    = get_the_permalink();
$categories   = get_categories(
        array (
            'hide_empty' => true,
        )
);
if ( class_exists( 'acf' ) ) {
    $blog_cta_label     = get_field( 'seg_blog_cta_label', 'option' );
    $blog_page_subtitle = get_field( 'seg_blog_page_subtitle', $page_id );
}
?>
<div class="flooring-blog-cat-tab">
    <ul>
        <li class="cat-list_item active" data-slug="">All</li>
<?php
if ( ! empty( $categories ) ) {
    foreach ( $categories as $key => $category ) {
        ?>
                <a href="<?php echo get_category_link( $category ); ?>">
                    <li class="cat-list_item" data-slug="<?php echo $category->slug; ?>"><?php echo $category->name; ?></li>
                </a>
        <?php
    }
}
?>
    </ul>
</div>
<?php
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

$loop = new WP_Query(
        array (
    'post_type'      => 'post',
    'post_status'    => 'publish',
    'posts_per_page' => 9,
    'order'          => 'ASC',
    'paged'          => $paged,
        ) );
if ( $loop->have_posts() ) {
    while ( $loop->have_posts() ) {
        $loop->the_post();
        $post_id        = get_the_ID();
        $post_title     = get_the_title();
        $post_content   = get_the_content();
        $post_thumbnail = get_the_post_thumbnail_url();
        $img_id         = get_post_thumbnail_id( $post_id );
        $image_alt      = get_post_meta( $img_id, '_wp_attachment_image_alt', true );
        $category       = wp_get_post_terms( get_the_ID(), 'category', array ( 'fields' => 'all' ) );
        $cat_id         = $category[ 0 ]->term_id;
        $cat_slug       = $category[ 0 ]->slug;
        $date           = get_the_date();
        $author         = get_the_author();
        echo $post_title . '<br>';
        echo $cat_slug . '<br>';
        echo $date . '<br>';
        echo $author . '<br>';
        echo '88888888' . '<br>';
    }
    wp_reset_query();
    wp_reset_postdata();
}
?>
<div class="pagination">
<?php
echo paginate_links( array (
    'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
    'total'        => $loop->max_num_pages,
    'current'      => max( 1, get_query_var( 'paged' ) ),
    'format'       => '?paged=%#%',
    'show_all'     => false,
    'prev_next'    => true,
    'prev_text'    => sprintf( '<i></i> %1$s', __( '>>', 'text-domain' ) ),
    'next_text'    => sprintf( '%1$s <i></i>', __( '<<', 'text-domain' ) ),
    'add_args'     => false,
    'add_fragment' => '',
) );
?>
</div>



<!--custom Template-->
<?php get_footer(); 
 * ?>
 */