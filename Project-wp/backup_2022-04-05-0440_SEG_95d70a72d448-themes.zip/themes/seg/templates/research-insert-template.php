<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) )
    exit;

/**
 * Template Name: Research Insert Template
 *
 * @package WordPress
 * @subpackage seg
 * @since seg 1.0
 */
get_header();
?>
<?php
if ( ($handle = fopen( "https://seg.compview.co/wp-content/uploads/2022/04/Research-Reports.csv", "r" )) !== FALSE ) {
    while ( ($data = fgetcsv( $handle, 10000, "," )) !== FALSE ) {
        if ( count( array_filter( $data ) ) != 0 ) {
            $final_data[] = $data;
        }
    }
    fclose( $handle );
}
$final_data = array_slice( $final_data, 1 );
//echo "<pre>";
//print_r( $final_data );
//echo "</pre>";
foreach ( $final_data as $key => $value ) {
    $post_title   = $value[ 1 ];
    $post_date    = $value[ 2 ];
    $post_old_url = $value[ 3 ];
    $post_url = str_replace ( 'https://softwareequity.com/', '', $post_old_url );
    $pdf          = $value[ 4 ];
    $report_cat   = $value[ 5 ];
    $thumbnail    = $value[ 6 ];
    $thumbnail    = str_replace( '.png', '', $thumbnail );
    $video        = $value[ 7 ];
    $content      = $value[ 8 ];
    
    $old_date_timestamp = strtotime( $post_date );
    $new_date           = date( 'Y-m-d', $old_date_timestamp );
    
    $checkTransection = get_page_by_title($post_title, 'OBJECT', SEG_RESEARCH_POST_TYPE);
    if ( !empty( $checkTransection ) ) {
        $ID = $checkTransection->ID;
        update_field( 'seg_res_page_form_scode', ' ' , $ID );
    }
    if ( empty( $checkTransection )  ) {
        $my_post                   = array (
            'post_type'   => SEG_RESEARCH_POST_TYPE,
            'post_title'  => $post_title,
            'post_name'   => $post_url,
            'post_date'   => $new_date,
            'post_content'=> $content,
            'post_status' => 'draft'
        );
        $post_id                   = wp_insert_post( $my_post );
        
        if( ! empty( $report_cat ) ) {
            $terms_vector = [];
            $term_name      = get_term_by( 'name', $report_cat, 'industry' );
            $terms_vector[] = $term_name->term_id;
            wp_set_post_terms( $post_id, $terms_vector, 'industry' );
        }
        $feat_image = getImageIDbyName($thumbnail);
        if ( empty( $feat_image ) ) {
            $feat_image = getImageIDbyName($thumbnail."-1");
        }
        if ( ! empty( $feat_image ) ) {
            set_post_thumbnail( $post_id, $feat_image );
        }
        
        update_field( 'seg_res_page_share_title', 'Share this snapshot' , $post_id );
        update_field( 'seg_research_access_cta_label', 'Access report' , $post_id );
        update_field( 'seg_res_page_form_scode', ' ' , $post_id );
        update_field( 'seg_research_subtitle', $post_title , $post_id );
        update_field( 'seg_res_page_report_desc', $content , $post_id );
        update_field( 'seg_res_page_form_title', "Download the ".$post_title , $post_id );
        if ( ! empty( $video ) ) {
            update_field( 'seg_res_page_content_sel', 1 , $post_id );
            update_field( 'seg_res_page_report_video', $video , $post_id );
        } else {
            update_field( 'seg_res_page_content_sel', 0 , $post_id );
        }
    }
}

function getImageIDbyName($name) {
    global $wpdb;
    $title_exists  = $wpdb->get_results( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_title = '$name' AND post_type = 'attachment'" ) );
    $attachment_id = '';
    if ( count( $title_exists ) > 0 ) {
        $attachment_id = $title_exists[ 0 ]->ID;
    }
    return $attachment_id;
}
?>
<?php
 get_footer(); ?>