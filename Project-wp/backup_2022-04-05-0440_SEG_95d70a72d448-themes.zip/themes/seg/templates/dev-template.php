<?php
// Exit if accessed directly
//if ( ! defined( 'ABSPATH' ) )
//    exit;
/*
 * Template Name: Dev Test Template
 *
 * @package WordPress
 * @subpackage seg
 * @since seg 1.0
 */
get_header();

$str = '{title:"The company",
 description:"AutoMon provides cloud-based case management and administrative solutions for the public sector. "The markets AutoMon serves are experiencing strong long-term tailwinds, including multiple macro drivers to develop recidivism-reduction strategies and calls for criminal justice reforms.​"},
 {title:"The software",
 description:"State and county agencies use the company’s solutions to manage the operations of their entire probation, pretrial, specialty court, re-entry, and diversion programs.​"},
 {title:"Headquarters",
 description:"Scottsdale, AZ"}';
$str  = str_replace('title:', '"title":', $str);
$str  = str_replace('description:', '"description":', $str);
echo "<pre>";
print_r($str);
echo "</pre>";
echo "<pre>";
//print_r( json_decode_add_quotes_to_keys("[".$str."]"));
print_r( json_decode("[".$str."]",true));
echo "</pre>";
update_field( 'seg_trans_right_content', json_decode("[".$str."]",true), 16729 );
die();
?>
<?php
if ( ($handle = fopen( "https://seg.compview.co/wp-content/uploads/2022/03/SEG-Transactions-DEV-eSpark-3.30.22-1-1.csv", "r" )) !== FALSE ) {
    while ( ($data = fgetcsv( $handle, 10000, "," )) !== FALSE ) {
        if ( count( array_filter( $data ) ) != 0 ) {
            $final_data[] = $data;
        }
    }
    fclose( $handle );
}
//$final_data = array_slice( $final_data, 0, 8 );
//echo "<pre>";
//print_r( $final_data );
//echo "</pre>";
foreach ( $final_data as $key1 => $value ) {
    $post_title       = $value[ 0 ];
    $post_url         = str_replace('/transactions/','' ,$value[ 2 ] );
    $post_date        = $value[ 3 ];
    $seo_title        = $value[ 4 ];
    $seo_description  = $value[ 5 ];
    $hide_transaction = $value[ 23 ];
    //post date
    $length           = strlen( $post_date );
    if ( $length == 4 ) {
        $new_date = str_replace( $post_date, $post_date . "-01-01", $post_date );
    } else {
        $old_date_timestamp = strtotime( $post_date );
        $new_date           = date( 'Y-m-d', $old_date_timestamp );
    }

    $trans_img2 = $value[ 8 ];
    $trans_img2 = explode( PHP_EOL, $trans_img2 );
    $trans_img2 = array_map( function ($item) {
        $item = str_replace( '.png,', '', $item );
        $item = str_replace( '.png', '', $item );
        $item = str_replace( 'Irg', 'lrg', $item );
        $item = str_replace( ' ', '', $item );
        return $item;
    }, $trans_img2 );
    $trans_img_large = array_map( function ($item) {
        return getImageIDbyName( $item );
    }, $trans_img2 );
    
    $trans_img_sm = $value[ 7 ];
    $trans_img_sm = explode( PHP_EOL, $trans_img_sm );
    $trans_img_sm = array_map( function ($item) {
        $item = str_replace( '.png,', '', $item );
        $item = str_replace( '.png', '', $item );
        $item = str_replace( ' ', '', $item );
        return $item;
    }, $trans_img_sm );
    $trans_img_small = array_map( function ($item) {
        return getImageIDbyName( $item );
    }, $trans_img_sm );

    $bread_crumb_post_title = $value[ 9 ];
    $banner_title           = $value[ 10 ];
    $banner_description     = $value[ 11 ];
    $video_img              = $value[ 17 ];
    $video_popup_iframe     = $value[ 13 ];
    $person_name            = $value[ 14 ];
    $person_designation     = $value[ 15 ];
    $testi_content          = '';
    $testi_content          = $value[ 16 ];
    $testi_content          = substr( $testi_content, 0, strrpos( $testi_content, '},' ) ) . "}";
    $client_images          = $value[ 17 ];

    $img_bottom_text           = $value[ 18 ];
    $client_des_title          = $value[ 19 ];
    $client_description = ''; 
    $client_description        = $value[ 20 ];
    $invest_des_title          = $value[ 21 ];
    $invest_description        = $value[ 22 ];
//    $hide_tran_section         = $value[ 23 ]; //no need
    $hide_tran_section         = 'No'; //no need
    $slider_title              = $value[ 24 ];
    $press_subtitle            = $value[ 25 ];
    $press_title               = $value[ 26 ];
    $press_descr               = $value[ 27 ];
    $read_full_press_cta_label = $value[ 28 ];
    $read_full_press_cta_link  = '#';
    $product_categories        = $value[ 30 ];
    $product_categories        = $product_categories != 'x' ? $product_categories : '';
    $vertical_categories       = $value[ 31 ];
    $vertical_categories        = $vertical_categories != 'x' ? $vertical_categories : '';
    $primary_product           = $value[ 32 ];
    $primary_product        = $primary_product != 'x' ? $primary_product : '';
    $primary_vertical          = $value[ 33 ];
    $primary_vertical        = $primary_vertical != 'x' ? $primary_vertical : '';
    $secondery_product         = $value[ 34 ];
    $secondery_product        = $secondery_product != 'x' ? $secondery_product : '';
    $secondery_vertical        = $value[ 35 ];
    $secondery_vertical        = $secondery_vertical != 'x' ? $secondery_vertical : '';
//    $third_product            = $value[ 36 ];
//    $third_vertical           = $value[ 37 ];
    $checkTransection = get_page_by_title($post_title, 'OBJECT', SEG_TRANSACTION_POST_TYPE);
    $post_id = '';
    
    if ( !empty( $checkTransection ) ) {
        $ID = $checkTransection->ID;
        if ( ! empty( $client_description ) ) {
            $client_desc = $client_description;
            if ( strrpos( $client_description, '},' ) > 0 ) {
                if ( (strrpos( $client_description, '},' ) +2) >= strlen( $client_description )) {
                    $client_desc    = substr( $client_description, 0, strrpos( $client_description, '},' ) ) . "}";
                }
            }
            $updated = '';
            $client_desc  = str_replace('title:', '"title":', $client_desc);
            $client_desc  = str_replace('description:', '"description":', $client_desc);
            $updated =  json_decode("[".$client_desc."]",true);
            echo "<pre>";
            echo $ID."============================================================";
            print_r(strlen( $client_description )."==");
            print_r(strrpos( $client_description, '},' ));
            print_r($client_desc);
            print_r($client_description);
            print_r($updated);
            echo "============================================================";
            echo "</pre>";
//            $updated = json_decode_add_quotes_to_keys( "[".$client_desc."]" );
            update_field( 'seg_trans_right_content', $updated, $ID );
        }
        if ( ! empty( $invest_description ) ) {
            $invest_desc = $invest_description;
            if ( strrpos( $invest_description, '},' ) > 0 ) {
                if ( (strrpos( $invest_description, '},' ) +2) >= strlen( $invest_description )) {
                    $invest_desc    = substr( $invest_description, 0, strrpos( $invest_description, '},' ) ) . "}";
                }
            }
            $updated = '';
            $invest_desc  = str_replace('title:', '"title":', $invest_desc);
            $invest_desc  = str_replace('description:', '"description":', $invest_desc);
            $updated =  json_decode("[".$invest_desc."]",true);
            echo "<pre>";
            echo $ID."============================================================";
            print_r($invest_desc);
//            print_r($invest_description);
            print_r($updated);
            echo "============================================================";
            echo "</pre>";
//            $updated = '';
//            $updated = json_decode_add_quotes_to_keys( "[".$invest_desc."]" );
            update_field( 'seg_trans_left_content', $updated, $ID );
        }
    }
    if ( empty( $checkTransection ) ) {
        $my_post                   = array (
            'post_type'   => SEG_TRANSACTION_POST_TYPE,
            'post_title'  => $post_title,
            'post_name'   => $post_url,
            'post_date'   => $new_date,
            'post_status' => 'publish'
        );
        $post_id                   = wp_insert_post( $my_post );
        echo "<pre>";
        print_r($my_post);
        echo "</pre>";
        echo "<pre>";
        print_r($post_id);
        echo "</pre>";
        $product_categories        = explode( ",", $product_categories );
        $vertical_categories       = explode( ",", $vertical_categories );

    //    update_field( 'seg_trans_right_content', $updated_client_con, $post_id );
        update_post_meta( $post_id, '_yoast_wpseo_title', $seo_title );
        update_post_meta( $post_id, '_yoast_wpseo_metadesc', $seo_description );
    }

//    $post_id = 15301;
    if ( $post_id ) {
        echo "<pre>";
        print_r($hide_transaction);
        echo "</pre>";
        if ( $hide_transaction == 'No' ) {
            update_field( 'seg_hide_in_transaction_slider', false, $post_id );
        } else {
            update_field( 'seg_hide_in_transaction_slider', true, $post_id );
        }
        if ( $hide_tran_section == 'yes' ) {
            update_field( 'seg_trans_slider_hide', 1, $post_id );
        } else {
            update_field( 'seg_trans_slider_hide', 0, $post_id );
        }
        //primary category
        $terms = array ();
        foreach ( $product_categories as $key => $value ) {
            if ( ! empty( $value ) ) {
                if ( ! term_exists( $value, 'product' ) ) {
                    $term_id = wp_insert_term( $value, 'product' );
                    if ( is_wp_error( $term_id ) ) {
                        if ( $term_id->errors['term_exists'] ) {
                            $terms[] = $term_id->error_data['term_exists'];
                        }
                    } else {
                        $terms[] = $term_id[ 'term_id' ];
                    }
                    wp_set_post_terms( $post_id, $terms, 'product' );
                } else {
                    $term_name = get_term_by( 'name', $value, 'product' );
                    $terms[]   = $term_name->term_id;
                    wp_set_post_terms( $post_id, $terms, 'product' );
                }
            }
        }
        $terms_vector = array ();
        foreach ( $vertical_categories as $key => $value ) {
            if ( ! empty( $value ) ) {
                if ( ! term_exists( $value, 'vertical' ) ) {
                    $term_id        = wp_insert_term( $value, 'vertical' );
                    if ( is_wp_error( $term_id ) ) {
                        if ( $term_id->errors['term_exists'] ) {
                            $terms[] = $term_id->error_data['term_exists'];
                        }
                    } else {
                        $terms[] = $term_id[ 'term_id' ];
                    }
                    $terms_vector[] = $term_id[ 'term_id' ];
                    wp_set_post_terms( $post_id, $terms_vector, 'vertical' );
                } else {
                    $term_name      = get_term_by( 'name', $value, 'vertical' );
                    $terms_vector[] = $term_name->term_id;
                    wp_set_post_terms( $post_id, $terms_vector, 'vertical' );
                }
            }
        }
        //for secondery terms
        if ( ! empty( $secondery_product ) ) {
            $secondery_product_name  = get_term_by( 'name', $secondery_product, 'product' );
            $secondery_product_id    = $secondery_product_name->term_id;
            update_field( 'seg_product_secondery', $secondery_product_id, $post_id );
        }
        if ( ! empty( $secondery_vertical ) ) {
            $secondery_vertical_name = get_term_by( 'name', $secondery_vertical, 'vertical' );
            $secondery_vertical_id   = $secondery_vertical_name->term_id;
            update_field( 'seg_vertical_secondery', $secondery_vertical_id, $post_id );
             
        }

        //transsaction images
        if ( ! empty( $trans_img_large ) ) {
            $new_tra_img_logo = array ();
            foreach ( $trans_img_large as $key => $value ) {
                $new_tra_img_logo[ 'logo' ] = $value;
                add_row( 'seg_trans_desr_logos', $new_tra_img_logo, $post_id );
            }
        }
        if ( ! empty( $trans_img_small ) ) {
            $new_tra_img_arr = array ();
            foreach ( $trans_img_small as $key => $value ) {
                $new_tra_img_arr[ 'image' ] = $value;
                add_row( 'seg_trans_images', $new_tra_img_arr, $post_id );
            }
        }
        //bread title
        if ( ! empty( $bread_crumb_post_title ) ) {
            update_field( 'seg_trans_bread_title', $bread_crumb_post_title, $post_id );
        }
        //banner section
        if ( ! empty( $banner_title ) ) {
            update_field( 'seg_trans_banner_title', $banner_title, $post_id );
        }
        if ( ! empty( $banner_description ) ) {
            update_field( 'seg_trans_banner_content', $banner_description, $post_id );
        }

        if ( ! empty( $video_popup_iframe ) ) {
            update_field( 'seg_trans_video_iframe', $video_popup_iframe, $post_id );
        }
        if ( ! empty( $person_name ) ) {
            update_field( 'seg_trans_video_subtext', $person_name, $post_id );
        }
        if ( ! empty( $person_designation ) ) {
            update_field( 'seg_trans_video_designation', $person_designation, $post_id );
        }

        //testinomial content
        if ( ! empty( $testi_content ) ) {
            $updated = [];
            $updated[] = json_decode_add_quotes_to_keys( $testi_content );
            update_field( 'seg_trans_test_content', $updated, $post_id );
        }

        ///description section
        $client_images = explode( PHP_EOL, $client_images );
        $client_images = array_map( function ($item) {
            $item = str_replace( '.jpg,', '', $item );
            $item = str_replace( '.jpg', '', $item );
            $item = str_replace( ' ', '', $item );
            return $item;
        }, $client_images );

        $client_images = array_map( function ($item) {
            return getImageIDbyName( $item );
        }, $client_images );

        if ( ! empty( $client_images ) ) {
            update_field( 'seg_trans_video_img', $client_images[ 0 ], $post_id );
        }
        if ( ! empty( $img_bottom_text ) ) {
            update_field( 'seg_trans_des_img_subtext', $img_bottom_text, $post_id );
        }
        if ( ! empty( $client_des_title ) ) {
            update_field( 'seg_trans_right_title', $client_des_title, $post_id );
        }
        //client description
        if ( ! empty( $client_description ) ) {
            if ( strrpos( $client_description, '},' ) > 0 ) {
                $client_desc    = substr( $client_description, 0, strrpos( $client_description, '},' ) ) . "}";
            }
            $updated = '';
            $updated = json_decode_add_quotes_to_keys( "[".$client_desc."]" );
            update_field( 'seg_trans_right_content', $updated, $post_id );
        }
        if ( ! empty( $invest_description ) ) {
            if ( strrpos( $invest_description, '},' ) > 0 ) {
                $invest_desc    = substr( $invest_description, 0, strrpos( $invest_description, '},' ) ) . "}";
            }
            $updated = '';
            $updated = json_decode_add_quotes_to_keys( "[".$invest_desc."]" );
            update_field( 'seg_trans_left_content', $updated, $post_id );
        }
        if ( ! empty( $invest_des_title ) ) {
            update_field( 'seg_trans_left_title', $invest_des_title, $post_id );
        }
//left content
//        if ( ! empty( $invest_description ) ) {
//            $invest_desc    = substr( $invest_description, 0, strrpos( $invest_description, '},' ) ) . "}";
//            $updated = [];
//            $updated[] = json_decode_add_quotes_to_keys( $invest_desc );
//            update_field( 'seg_trans_left_content', $updated, $post_id );
//            
////            $additions_invest = json_decode_add_quotes_to_keys( '[' . $invest_description . ']' );
//        }
//        $existing_invest_con = get_field( 'seg_trans_left_content' );
//        if ( ! is_array( $existing_invest_con ) ) {
//            $existing_invest_con = [];
//        }
//        if ( ! empty( $additions_invest) ) {
//            $updated_invest_con = $existing_invest_con + $additions_invest;
//            update_field( 'seg_trans_left_content', $updated_invest_con, $post_id );
//        }

        //press_release

        if ( ! empty( $slider_title ) ) {
            update_field( 'seg_trans_slider_title', $slider_title, $post_id );
        }
        if ( ! empty( $press_subtitle ) ) {
            update_field( 'seg_press_subtitle', $press_subtitle, $post_id );
        }
        if ( ! empty( $press_title ) ) {
            update_field( 'seg_press_title', $press_title, $post_id );
        }
        if ( ! empty( $press_descr ) ) {
            update_field( 'seg_press_content', $press_descr, $post_id );
        }

        $press_arr = array (
            'title' => $read_full_press_cta_label,
            'url'   => $read_full_press_cta_link,
        );
        if ( ! empty( $press_arr ) ) {
            update_field( 'seg_press_read_cta', $press_arr, $post_id );
        }
        if ( ! empty( $slider_title ) ) {
            update_field( 'seg_trans_slider_title', $slider_title, $post_id );
        }
        if ( ! empty( $press_subtitle ) ) {
            update_field( 'seg_press_subtitle', $press_subtitle, $post_id );
        }
        if ( ! empty( $press_title ) ) {
            update_field( 'seg_press_title', $press_title, $post_id );
        }
        if ( ! empty( $press_descr ) ) {
            update_field( 'seg_press_content', $press_descr, $post_id );
        }

        $press_arr = array (
            'title' => $read_full_press_cta_label,
            'url'   => $read_full_press_cta_link,
        );
        if ( ! empty( $press_arr ) ) {
            update_field( 'seg_press_read_cta', $press_arr, $post_id );
        }
        $primary_product = get_term_by('name',$primary_product,'product');
        if ( ! empty( $primary_product ) ) {
//            wpseoPrimaryTerm('product', $post_id, $primary_product);
            update_post_meta($post_id,'_yoast_wpseo_primary_product',$primary_product->term_id);
        }
        $primary_vertical = get_term_by('name',$primary_vertical,'vertical');
        if ( ! empty( $primary_vertical ) ) {
//            wpseoPrimaryTerm('vertical', $post_id, $primary_vertical);
            update_post_meta($post_id,'_yoast_wpseo_primary_vertical',$primary_product->term_id);
        }
    }
}

function getImageIDbyName($name) {
    global $wpdb;
    $title_exists  = $wpdb->get_results( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_title = '$name' AND post_type = 'attachment'" ) );
    $attachment_id = '';
    if ( count( $title_exists ) > 0 ) {
        $attachment_id = $title_exists[ 0 ]->ID;
    }
    return $attachment_id;
}

function json_decode_add_quotes_to_keys($s) {
    $s = preg_replace( '/(\w+):/i', '"\1":', $s );
    return json_decode( $s, true );
}
function wpseoPrimaryTerm($taxonomy, $postID, $term){

  if ( class_exists('WPSEO_Primary_Term') ) {
  // Set primary term.
  $primaryTermObject = new WPSEO_Primary_Term($taxonomy, $postID);
  $primaryTermObject->set_primary_term($term);

//  // Save primary term.
//  $primaryTermObjectAdmin = new WPSEO_Primary_Term_Admin();
//  $primaryTermObjectAdmin->save_primary_terms($postID);
  }else{
    echo 'Class WPSEO does not exit';
  }
}
?>
<?php
get_footer();
?>