<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) )
    exit;

/**
 * Template Name: Blog Insert Template
 *
 * @package WordPress
 * @subpackage seg
 * @since seg 1.0
 */
//get_header();
die();
?>

<?php
if ( ($handle = fopen( "https://seg.compview.co/wp-content/uploads/2022/03/SEG-Blog-URLs-eSpark-_1_.csv", "r" )) !== FALSE ) {
    while ( ($data = fgetcsv( $handle, 10000, "," )) !== FALSE ) {
        if ( count( array_filter( $data ) ) != 0 ) {
            $final_data[] = $data;
        }
    }
    fclose( $handle );
}
//$final_data = array_slice( $final_data, 1, 1 );
//echo "<pre>";
//print_r( $final_data );
//echo "</pre>";
foreach ( $final_data as $key => $value ) {
//    $new_url       = $value[ 2 ];
//    $visit         = $value[ 0 ];
    $link          = $value[ 1 ];
    $page_type     = $value[ 3 ];
    $blog_category = $value[ 4 ];
    if ( $blog_category != 'Remove' ) {
        if ( $post = get_page_by_path( $link, OBJECT, 'post' ) ) {
            $post_id     = $post->ID;
            echo "<pre>";
            print_r( "Post ID : " .$post_id );
            echo "</pre>";
            echo "<pre>";
            print_r( $blog_category );
            echo "</pre>";
            $category_id = get_cat_ID( $blog_category );
            echo "<pre>";
            print_r( $category_id );
            echo "</pre>";
            wp_set_post_categories( $post_id, $category_id, false );
        }
    }
}
?>
<?php
//get_footer();
?>