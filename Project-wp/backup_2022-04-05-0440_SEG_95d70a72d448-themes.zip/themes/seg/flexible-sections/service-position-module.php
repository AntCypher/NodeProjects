<!--second Section-->
<?php
if ( class_exists( 'acf' ) ) {
    $title            = get_sub_field( 'title' );
    $description      = get_sub_field( 'description' );
    $position_content = get_sub_field( 'postions_content' );
}
if ( ! empty( $title ) || ! empty( $description ) || ! empty( $position_content ) ) {
    ?>
    <section class="service-position-section">
        <div class="container">
            <div class="row">
                <div class="col-100">
                    <div class="sect_header">
                        <?php if ( ! empty( $title ) ) { ?>
                            <h2><?php echo $title; ?></h2>
                        <?php } echo $description; ?>
                    </div>
                </div>
                <div class="col-100 ">
                    <?php if ( ! empty( $position_content ) ) { ?>
                        <div class="service-position-tabing tabs-nav">
                            <?php
                            foreach ( $position_content as $key => $value ) {
                                $position_name = $value[ 'position_name' ];
                                $class         = ($key == 0) ? 'active' : '';
                                ?>
                                <div class="service-position-tab <?php echo $class; ?>"><a href="#tab<?php echo $key + 1; ?>"><?php echo $position_name; ?></a></div>
                                <!--<div class="service-position-tab"><a href="#tab2">PE Firms</a></div>-->
                            <?php } ?>
                        </div>
                    <?php } ?>
                </div>
                <?php if ( ! empty( $position_content ) ) { ?>
                    <div class="col-100 tabs-content">
                        <?php
                        foreach ( $position_content as $key => $value ) {
                            $position_name  = $value[ 'position_name' ];
                            $position_descr = $value[ 'position_description' ];
                            $cta            = $value[ 'cta' ];
                            $image          = $value[ 'image' ];
                            $img_url        = ! empty( $image ) ? $image[ 'url' ] : '#';
                            $img_alt        = ! empty( $image[ 'alt' ] ) ? $image[ 'alt' ] : get_bloginfo();
                            if ( ! empty( $cta ) ) {
                                $cta_title  = $cta[ 'title' ];
                                $cta_url    = $cta[ 'url' ];
                                $cta_target = $cta[ 'target' ];
                            }
                            ?>
                            <div id="tab<?php echo $key + 1; ?>">
                                <div  class="service-position-box">
                                    <div class="service-position-row">
                                        <div class="service-position-contain">
                                            <div class="service-position-wrap">
                                                <?php if(!empty($position_name)) { ?>
                                                <h2 class="service-position-title"><?php echo $position_name; ?></h2>
                                                <?php }  echo $position_descr; ?>
                                                <?php if ( ! empty( $cta ) ) { ?>
                                                    <a href="<?php echo $cta_url; ?>" class="btn btn-primary" target="<?php echo $cta_target; ?>"><?php echo $cta_title; ?></a>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <?php if ( ! empty( $image ) ) { ?>
                                            <div class="service-position-img">
                                                <img src="<?php echo $img_url; ?>" alt="<?php echo $img_alt; ?>">
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>
<?php } ?>
