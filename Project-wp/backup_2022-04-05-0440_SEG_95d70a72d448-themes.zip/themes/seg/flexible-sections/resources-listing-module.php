<!--resources listing-->
<?php
if ( class_exists( 'acf' ) ) {
    $hide_resource  = get_sub_field( 'hide_resource' );
    $resource_media = get_sub_field( 'resource_media' );
    $select_media   = get_sub_field( 'select__resouces_media_' );
    if ( $resource_media ) {
        $media = get_terms(
                array (
                    'taxonomy'   => SEG_MEDIA_TAX,
                    'hide_empty' => false,
                )
        );
    }
    if ( ! $resource_media ) {
        $media = get_terms(
                array (
                    'taxonomy'   => SEG_MEDIA_TAX,
                    'include'    => $select_media,
                    'hide_empty' => false,
                )
        );
    }
}
if ( ! $hide_resource ) {
    ?>
    <section class="resource-listing-section">
        <div class="container">
            <div class="row">
                <div class="col-100">
                    <div class="resource-tags-filter">
                        <div class="inner-wrapper">
                            <?php if ( ! empty( $media ) ) { ?>
                                <ul class="tags-list">
                                    <li class="tag-item active"  data-slug=""><a href="#" class="tag-link">All</a></li>
                                    <?php
                                    foreach ( $media as $key => $media_val ) {
                                        $term_id    = $media_val->term_id;
                                        $media_name = $media_val->name;
                                        $media_slug = $media_val->slug;
                                        ?>
                                        <li class="tag-item" data-slug="<?php echo $media_slug; ?>"><a href="#" class="tag-link"><?php echo $media_name; ?></a></li>
                                        <!--                            <li class="tag-item"><a href="#" class="tag-link">SEG Insights</a></li>
                                                                    <li class="tag-item"><a href="#" class="tag-link">Webinars</a></li>
                                                                    <li class="tag-item"><a href="#" class="tag-link">Virtual Coffee with SEG</a></li>
                                        -->
                                    <?php } ?>
                                </ul>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="col-100">
                    <div class="row" id="load-resouces-content">
                        <?php fun_resource_filter(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php } ?>
