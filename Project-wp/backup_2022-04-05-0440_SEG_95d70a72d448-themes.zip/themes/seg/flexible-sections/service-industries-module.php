<!--4th Section-->
<?php
if ( class_exists( 'acf' ) ) {
    $title            = get_sub_field( 'title' );
    $description      = get_sub_field( 'description' );
    $pro_title        = get_sub_field( 'product_content_title' );
    $ver_title        = get_sub_field( 'vertical_content_title' );
    $product_content  = get_sub_field( 'product_content' );
    $vertical_content = get_sub_field( 'verical_content' );
    $image            = get_sub_field( 'image' );
    $img_url          = ! empty( $image ) ? $image[ 'url' ] : '#';
    $img_alt          = ! empty( $image[ 'alt' ] ) ? $image[ 'alt' ] : get_bloginfo();
}
if ( ! empty( $title ) || ! empty( $description ) || ! empty( $pro_title ) || ! empty( $ver_title ) || ! empty( $product_content ) || ! empty( $vertical_content ) || ! empty( $image ) ) {
    ?>
    <section class="service-industries-section">
        <div class="container">
            <div class="row">
                <div class="col-100">
                    <div class="sect_header">
                        <?php if ( ! empty( $title ) ) { ?>
                            <h2><?php echo $title; ?></h2>
                        <?php } echo $description; ?>
                    </div>
                </div>

                <div class="col-100">
                    <div class="service-industries-inner">
                        <div class="service-industries-list">
                            <div class="service-industries-wrap">
                                <div class="service-industries-col">
                                    <?php if ( ! empty( $pro_title ) ) { ?>
                                        <h4 class="service-industries-title"><?php echo $pro_title; ?></h4>
                                    <?php } ?>
                                    <?php if ( ! empty( $product_content ) ) { ?>
                                        <ul>
                                            <?php
                                            foreach ( $product_content as $key => $value ) {
                                                $cta_text    = $value[ 'cta__text' ];
                                                $product_cta = $value[ 'product_cta' ];
                                                $pro_text    = $value[ 'product_text' ];
                                                if ( $cta_text && ! empty( $pro_text ) ) {
                                                    ?>
                                                    <li><?php echo $pro_text; ?></li>
                                                <?php } else if ( ! $cta_text && ! empty( $product_cta ) ) { ?>
                                                    <li><a href="<?php echo $product_cta[ 'url' ]; ?>" target="<?php echo $product_cta[ 'target' ]; ?>"><?php echo $product_cta[ 'title' ]; ?></a></li>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </ul>
                                    <?php } ?>
                                </div>
                                <div class="service-industries-col">
                                    <?php if ( ! empty( $ver_title ) ) { ?>
                                        <h4 class="service-industries-title"><?php echo $ver_title; ?></h4>
                                    <?php } ?>
                                    <?php if ( ! empty( $vertical_content ) ) { ?>
                                        <ul>
                                            <?php
                                            foreach ( $vertical_content as $key => $value ) {
                                                $cta_text      = $value[ 'cta__text' ];
                                                $vertical_cta  = $value[ 'vertical_cta' ];
                                                $vertical_text = $value[ 'vertical_text' ];
                                                if ( $cta_text && ! empty( $vertical_text ) ) {
                                                    ?>
                                                    <li><?php echo $vertical_text; ?></li>
                                                <?php } else if ( ! $cta_text && ! empty( $vertical_cta ) ) { ?>
                                                    <li><a href="<?php echo $vertical_cta[ 'url' ]; ?>" target="<?php echo $vertical_cta[ 'target' ]; ?>"><?php echo $vertical_cta[ 'title' ]; ?></a></li>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </ul>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                        <?php if ( ! empty( $image ) ) { ?>
                            <div class="service-industries-img">
                                <img src="<?php echo $img_url; ?>" alt="<?php echo $img_alt; ?>">
                            </div>
                        <?php } ?>
                    </div>
                </div>

            </div>
        </div>
    </section>
<?php } ?>
