<!--third Section-->
<?php
if ( class_exists( 'acf' ) ) {
    $hide_title_descr   = get_sub_field( 'hide_title_descr' );
    $title              = get_sub_field( 'title' );
    $descr              = get_sub_field( 'description' );
    $hide_broad_process = get_sub_field( 'hide_broad_process_section' );
    $image              = get_sub_field( 'image' );
    $img_url            = ! empty( $image ) ? $image[ 'url' ] : '#';
    $img_alt            = ! empty( $image[ 'alt' ] ) ? $image[ 'alt' ] : get_bloginfo();
    $process_title      = get_sub_field( 'process_title' );
    $process_descr      = get_sub_field( 'process_description' );
    $process_cta        = get_sub_field( 'process_cta' );
    $hide_process_type  = get_sub_field( 'hide_process_type_section' );
    $process_content    = get_sub_field( 'process_contents' );
    if ( ! empty( $process_cta ) ) {
        $process_cta_title  = $process_cta[ 'title' ];
        $process_cta_link   = $process_cta[ 'url' ];
        $process_cta_target = $process_cta[ 'target' ];
    }
}
if ( ! empty( $title ) || ! empty( $descr ) || ! empty( $image ) || ! empty( $process_title ) || ! empty( $process_descr ) || ! empty( $process_content ) || ! empty( $process_cta ) ) {
    ?>
    <section class="service-step-market-section">
        <div class="container">
            <div class="row">
                <?php if ( ! $hide_title_descr ) { ?>
                    <div class="col-100">
                        <div class="sect_header">
                            <?php if ( ! empty( $title ) ) { ?>
                                <h2><?php echo $title; ?></h2>
                            <?php } echo $descr; ?>
                        </div>
                    </div>
                <?php } ?>
                <?php if ( ! $hide_broad_process ) { ?>
                    <div class="col col-100 step-market-full">
                        <div class="service-step-market-box">
                            <?php if ( ! empty( $image ) ) { ?>
                                <div class="service-step-market-img">
                                    <img src="<?php echo $img_url; ?>" alt="<?php echo $img_alt; ?>">
                                </div>
                            <?php } ?>
                            <div class="service-step-market-contain">
                                <div class="service-step-market-wrap">
                                    <?php if ( ! empty( $process_title ) ) { ?>
                                        <h2 class="service-step-market-title"><?php echo $process_title; ?></h2>
                                        <?php
                                    }
                                    echo $process_descr;
                                    if ( ! empty( $process_cta ) ) {
                                        ?>
                                        <a href="<?php echo $process_cta_link; ?>" class="btn btn-primary" target="<?php echo $process_cta_target; ?>"><?php echo $process_cta_title; ?></a>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <?php
                if ( ! $hide_process_type ) {
                    if ( ! empty( $process_content ) ) {
                        foreach ( $process_content as $key => $value ) {
                            $title       = $value[ 'title' ];
                            $descprition = $value[ 'descprition' ];
                            ?>
                            <div class="col col-33">
                                <div class="service-step-market-box">
                                    <div class="service-step-market-contain">
                                        <div class="service-step-market-wrap">
                                            <?php if ( ! empty( $title ) ) { ?>
                                                <h2 class="service-step-market-title"><?php echo $title; ?></h2>
                                            <?php } echo $descprition; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }
                }
                ?>
            </div>
        </div>
    </section>
<?php } ?>
