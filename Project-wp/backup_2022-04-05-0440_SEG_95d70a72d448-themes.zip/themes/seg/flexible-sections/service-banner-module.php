<!--first Section-->
<?php
if ( class_exists( 'acf' ) ) {
    $bg_img      = get_sub_field( 'background_image' );
    $bg_img_url  = ! empty( $bg_img ) ? $bg_img[ 'url' ] : '#';
    $bg_img_alt  = ! empty( $bg_img[ 'alt' ] ) ? $bg_img[ 'alt' ] : get_bloginfo();
    $subtext     = get_sub_field( 'subtext' );
    $title       = get_sub_field( 'title' );
    $description = get_sub_field( 'description' );
}
if ( ! empty( $bg_img ) || ! empty( $subtext ) || ! empty( $title ) || ! empty( $description ) ) {
    ?>
    <section class="service-banner-section">
        <?php if ( ! empty( $bg_img ) ) { ?>
            <div class="service-banner-wrapper">
                <img src="<?php echo $bg_img_url; ?>" alt="<?php echo $bg_img_alt; ?>">
            </div>
        <?php } ?>
        <div class="service-banner-contant">
            <div class="container">
                <div class="cs-text-wrapper">
                    <div class="inner-wrapper">
                        <?php if ( ! empty( $subtext ) ) { ?>
                            <span class="sub-title"><?php echo $subtext; ?></span>
                        <?php } if ( ! empty( $title ) ) { ?>
                            <h1 class="page-title"><?php echo $title; ?></h1>
                        <?php } echo $description; ?>
                    </div>
                    <img class="arrow-img" src="<?php echo get_template_directory_uri(); ?>/images/ser-banner-arrow-forward.png" alt="">
                </div>
            </div>
        </div>
    </section>
<?php } ?>
