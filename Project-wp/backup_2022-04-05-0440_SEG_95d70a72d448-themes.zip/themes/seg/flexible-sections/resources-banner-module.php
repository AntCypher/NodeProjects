<!--resources banner--> 
<?php
if ( class_exists( 'acf' ) ) {
    $bg_img      = get_sub_field( 'bg_img' );
    $bg_img_url  = ! empty( $bg_img ) ? $bg_img[ 'url' ] : '#';
    $bg_alt      = ! empty( $bg_img[ 'alt' ] ) ? $bg_img[ 'alt' ] : get_bloginfo();
    $subtext     = get_sub_field( 'subtext' );
    $title       = get_sub_field( 'title' );
    $description = get_sub_field( 'description' );
}
if ( ! empty( $bg_img ) || ! empty( $subtext ) || ! empty( $title ) || ! empty( $description ) ) {
    ?>
    <section class="resources-banner-section light" style="background-image: url(<?php echo $bg_img_url; ?>)">
        <div class="container">
            <h1 class="resources-banner-title">
                <?php if ( ! empty( $subtext ) ) { ?>
                    <span><?php echo $subtext; ?></span>
                <?php } ?>
                <?php echo $title; ?>
            </h1>
            <?php if ( ! empty( $description ) ) { ?>
                <div class="resources-banner-subtitle">
                    <?php echo $description; ?>
                </div>
            <?php } ?>
        </div>
    </section>
<?php } ?>
