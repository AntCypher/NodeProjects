var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"main-wrapper"},[_c('layout-headeradmin'),_vm._v(" "),_c('layout-sidebar'),_vm._v(" "),_c('div',{staticClass:"page-wrapper"},[_c('div',{staticClass:"content container-fluid"},[_c('div',{staticClass:"page-header"},[_c('div',{staticClass:"row"},[_c('div',{staticClass:"col-sm-12"},[_c('h3',{staticClass:"page-title"},[_vm._v("Blank Page")]),_vm._v(" "),_c('ul',{staticClass:"breadcrumb"},[_c('li',{staticClass:"breadcrumb-item"},[_c('router-link',{attrs:{"to":"/admin/index"}},[_vm._v("Dashboard")])],1),_vm._v(" "),_c('li',{staticClass:"breadcrumb-item active"},[_vm._v("Blank Page")])])])])]),_vm._v(" "),_vm._m(0)])])],1)}
var staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"row"},[_c('div',{staticClass:"col-sm-12"},[_vm._v("\n\t\t\t\t\t\t\tContents here\n\t\t\t\t\t\t")])])}]
var esExports = { render: render, staticRenderFns: staticRenderFns }
export default esExports


//////////////////
// WEBPACK FOOTER
// ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-adfab5b2","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/admin/blankpage.vue
// module id = null
// module chunks = 