var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"main-wrapper error-page"},[_c('div',{staticClass:"error-box"},[_c('h1',[_vm._v("404")]),_vm._v(" "),_vm._m(0),_vm._v(" "),_c('p',{staticClass:"h4 font-weight-normal"},[_vm._v("The page you requested was not found.")]),_vm._v(" "),_c('router-link',{staticClass:"btn btn-primary",attrs:{"to":"/admin/index"}},[_vm._v("Back to Home")])],1)])}
var staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('h3',{staticClass:"h2 mb-3"},[_c('i',{staticClass:"fa fa-warning"}),_vm._v(" Oops! Page not found!")])}]
var esExports = { render: render, staticRenderFns: staticRenderFns }
export default esExports


//////////////////
// WEBPACK FOOTER
// ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-71b88aa1","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/admin/error404.vue
// module id = null
// module chunks = 