var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"main-wrapper account-page"},[_c('div',{staticClass:"bg-pattern-style"},[_c('div',{staticClass:"content"},[_c('div',{staticClass:"account-content"},[_c('div',{staticClass:"account-box"},[_c('div',{staticClass:"login-right"},[_vm._m(0),_vm._v(" "),_c('form',[_vm._m(1),_vm._v(" "),_c('div',{staticClass:"text-right"},[_c('router-link',{staticClass:"forgot-link",attrs:{"to":"/pages/login"}},[_vm._v("Remember your password?")])],1),_vm._v(" "),_c('button',{staticClass:"btn btn-primary login-btn",attrs:{"type":"submit"}},[_vm._v("Reset Password")])])])])])])])])}
var staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"login-header"},[_c('h3',[_vm._v("Forgot Password?")]),_vm._v(" "),_c('p',{staticClass:"text-muted"},[_vm._v("Enter your email to get a password reset link")])])},function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"form-group"},[_c('label',{staticClass:"form-control-label"},[_vm._v("Email Address")]),_vm._v(" "),_c('input',{staticClass:"form-control",attrs:{"type":"email"}})])}]
var esExports = { render: render, staticRenderFns: staticRenderFns }
export default esExports


//////////////////
// WEBPACK FOOTER
// ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-ee07f4b2","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/website/pages/ForgotPassword.vue
// module id = null
// module chunks = 