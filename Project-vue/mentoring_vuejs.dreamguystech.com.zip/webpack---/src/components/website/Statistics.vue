var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _vm._m(0)}
var staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"section statistics-section"},[_c('div',{staticClass:"container"},[_c('div',{staticClass:"row"},[_c('div',{staticClass:"col-12 col-md-4"},[_c('div',{staticClass:"statistics-list text-center"},[_c('span',[_vm._v("500+")]),_vm._v(" "),_c('h3',[_vm._v("Happy Clients")])])]),_vm._v(" "),_c('div',{staticClass:"col-12 col-md-4"},[_c('div',{staticClass:"statistics-list text-center"},[_c('span',[_vm._v("120+")]),_vm._v(" "),_c('h3',[_vm._v("Online Appointments")])])]),_vm._v(" "),_c('div',{staticClass:"col-12 col-md-4"},[_c('div',{staticClass:"statistics-list text-center"},[_c('span',[_vm._v("100%")]),_vm._v(" "),_c('h3',[_vm._v("Job Satisfaction")])])])])])])}]
var esExports = { render: render, staticRenderFns: staticRenderFns }
export default esExports


//////////////////
// WEBPACK FOOTER
// ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-20977868","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/website/Statistics.vue
// module id = null
// module chunks = 