var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"main-wrapper"},[_c('layout-header'),_vm._v(" "),_c('home-banner'),_vm._v(" "),_c('mentoring-flow'),_vm._v(" "),_c('popular-mentors'),_vm._v(" "),_c('learning-path'),_vm._v(" "),_c('blogs'),_vm._v(" "),_c('statistics'),_vm._v(" "),_c('layout-footer')],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
export default esExports


//////////////////
// WEBPACK FOOTER
// ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-0437a53b","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/website/Index.vue
// module id = null
// module chunks = 