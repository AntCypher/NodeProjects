var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"main-wrapper"},[_c('layout-header1'),_vm._v(" "),_c('breadcrumb17'),_vm._v(" "),_c('div',{staticClass:"content"},[_c('div',{staticClass:"container-fluid"},[_c('div',{staticClass:"row"},[_c('div',{staticClass:"col-md-5 col-lg-4 col-xl-3 theiaStickySidebar"},[_c('sidebar')],1),_vm._v(" "),_vm._m(0)])])]),_vm._v(" "),_c('layout-footer')],1)}
var staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"col-md-7 col-lg-8 col-xl-9"},[_c('div',{staticClass:"card"},[_c('div',{staticClass:"card-body"},[_c('div',{staticClass:"row"},[_c('div',{staticClass:"col-md-12 col-lg-6"},[_c('form',[_c('div',{staticClass:"form-group"},[_c('label',[_vm._v("Old Password")]),_vm._v(" "),_c('input',{staticClass:"form-control",attrs:{"type":"password"}})]),_vm._v(" "),_c('div',{staticClass:"form-group"},[_c('label',[_vm._v("New Password")]),_vm._v(" "),_c('input',{staticClass:"form-control",attrs:{"type":"password"}})]),_vm._v(" "),_c('div',{staticClass:"form-group"},[_c('label',[_vm._v("Confirm Password")]),_vm._v(" "),_c('input',{staticClass:"form-control",attrs:{"type":"password"}})]),_vm._v(" "),_c('div',{staticClass:"submit-section"},[_c('button',{staticClass:"btn btn-primary submit-btn",attrs:{"type":"submit"}},[_vm._v("Save Changes")])])])])])])])])}]
var esExports = { render: render, staticRenderFns: staticRenderFns }
export default esExports


//////////////////
// WEBPACK FOOTER
// ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-0b38fa8e","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/website/mentee/ChangePassword.vue
// module id = null
// module chunks = 