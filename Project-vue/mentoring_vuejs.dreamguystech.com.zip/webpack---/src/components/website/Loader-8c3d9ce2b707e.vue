var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _vm._m(0)}
var staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"loader-wrapper"}},[_c('div',{attrs:{"id":"loader"}},[_c('div',{staticClass:"loader-ellips"},[_c('span',{staticClass:"loader-ellips__dot"}),_vm._v(" "),_c('span',{staticClass:"loader-ellips__dot"}),_vm._v(" "),_c('span',{staticClass:"loader-ellips__dot"}),_vm._v(" "),_c('span',{staticClass:"loader-ellips__dot"})])])])}]
var esExports = { render: render, staticRenderFns: staticRenderFns }
export default esExports


//////////////////
// WEBPACK FOOTER
// ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-d1bc5cba","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/website/Loader.vue
// module id = null
// module chunks = 