var normalizeComponent = require("!../../../../../node_modules/vue-loader/lib/component-normalizer")
/* script */
export * from "!!babel-loader!../../../../../node_modules/vue-loader/lib/selector?type=script&index=0!./SideBar.vue"
import __vue_script__ from "!!babel-loader!../../../../../node_modules/vue-loader/lib/selector?type=script&index=0!./SideBar.vue"
/* template */
import __vue_template__ from "!!../../../../../node_modules/vue-loader/lib/template-compiler/index?{\"id\":\"data-v-2e62b589\",\"hasScoped\":false,\"transformToRequire\":{\"video\":[\"src\",\"poster\"],\"source\":\"src\",\"img\":\"src\",\"image\":\"xlink:href\"},\"buble\":{\"transforms\":{}}}!../../../../../node_modules/vue-loader/lib/selector?type=template&index=0!./SideBar.vue"
/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __vue_script__,
  __vue_template__,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

export default Component.exports



//////////////////
// WEBPACK FOOTER
// ./src/components/layouts/website/mentor/SideBar.vue
// module id = null
// module chunks = 